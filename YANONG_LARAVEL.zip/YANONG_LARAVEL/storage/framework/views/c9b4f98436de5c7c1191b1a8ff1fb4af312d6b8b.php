<?php $__env->startSection("content"); ?>
    <div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
        	<h1>ALL ABOUT ME</h1>
          <br><br>
         	<H4 style="margin-left:100px">I am Yanong Kent Vincent from Bantayan Island, Cebu.<BR></H4>
          <H4>I am Yanong Kent Vincent from Bantayan Island, Cebu.<BR></H4>
              

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>