<?php $__env->startSection("content"); ?>
    <div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
        	<h1>ALL ABOUT ME</h1>
          <br><br>
          <div class="panel panel-default">
          	<div class="panel-body">
         	<H3 style="margin-left:25px;font-family:;">&nbsp &nbsp &nbsp&nbsp &nbsp &nbsp &nbsp &nbspI am Kent Vincent G. Yanong. I live in Alaska Mambaling Cebu City. I am 22 years old this year. I am studying Bachelor of Science in Computer Technoly in UC-Main Campus. I like staying in the house with the family to bond with. I have 3 other siblings 2 boys and 1 princess.<br><br> 

            &nbsp &nbsp &nbsp&nbsp &nbsp &nbsp &nbsp &nbspMy Hobbies are staying indoors, reading books, watching movies, listening to all sorts of music, playing board games and video games, and sleeping. My favorite fruit is all of them because im not picky. I love drinking coffee, hot choco and tea. I have going outdoor with any special gains, only wastes energy.<br><br>

            &nbsp &nbsp &nbsp&nbsp &nbsp &nbsp &nbsp &nbspI consider myself a very genuine, compassionate person. I may be over weight. but i love the thought of weight loss nutrition or personal fitness and its something i would love to get into. I have a bad habit of giving up on myself and I am working towards breaking that habit. I am overly generous and giving to people and easily get taken advantage of.<br><br>

            &nbsp &nbsp &nbsp&nbsp &nbsp &nbsp &nbsp &nbspOne of my many dreams is to travel around the world and to see the beauty of every places has to offer. I really really love my family because of raising me the way i am today. They al ways support me on every decision i make and they're always there to bring me up when im down. I'm really blessed and proud to have them as my parents.<BR></H3>
         </div>
         </div>
              

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>