<?php $__env->startSection("content"); ?>
<!DOCTYPE html>
<html>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">   
          <h1>MY ACADEMIC SCHEDULE</h1>
              <div class="panel panel-default">
              	<H3>
              	<table style="width:100%" border="1">
				  <tr>
				    <th>SUBJECT NAME</th>
				  </tr>
				  <tr>
				  <td>English 1C</td>
				  </tr>
				   <tr>
				  <td>Physics 1A lab</td>
				  </tr>
				   <tr>
				  <td>Physics 2A lab and lec</td>
				  </tr>
				   <tr>
				  <td>FreeEL-CIS</td>
				  </tr>
				   <tr>
				  <td>ITELEC-PHP2</td>
				  </tr>
				   <tr>
				  <td>Capstone 42</td>
				  </tr>
				   <tr>
				  <td>Practicum 42</td>
				  </tr>
				</table>
				</H3>
              </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>