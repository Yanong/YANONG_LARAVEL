<?php $__env->startSection("content"); ?>
    <div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
        	<h1>ABOUT MY EDUCATION</h1>

              <div class="panel panel-default">
              	<H3>
  				Primary Education: Mojon Elementary School Barangay, Mojon, Bantayan Island 2008 - 2009 <BR><BR>
  				Secondary Education: Bantayan National High School Ticad, Bantayan Island 2012 - 2013<BR><BR>
  				Tertiary Education: University of Cebu 2015 - (present) Cebu City<BR>
  				Course : Bachelor of Science in Information Technology<BR><BR>
          Datamex Institute of Computer Technology 2013 - 2015 Aston Gestus Bldg, Gorordo Ave, Cebu City
              </H3>
              </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>