<?php $__env->startSection("content"); ?>
    <div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
        	<h1>ABOUT MY EDUCATION</h1>
              <div class="panel panel-default">
              
                <div style="margin-top: -16px"  class="panel-body">
              <h3>
                <table>
                <tr height='60px'>
                  <td width="300px">
                    Primary School :
                  </td>
                  <td>
                    Alaska Elementary School Cebu City
                  </td>
                </tr>
                <tr height='60px'>
                  <td>
                    Secondary Education :
                  </td>
                  <td>
                    Alaska Night High School Cebu City
                  </td>
                </tr>
                <tr height='60px'>
                  <td>
                    Tertiary Education :
                  </td>
                  <td>
                    University of Cebu
                  </td>
                </tr>
              </td></tr></table>
            </h3>
            </div>
              
              </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>