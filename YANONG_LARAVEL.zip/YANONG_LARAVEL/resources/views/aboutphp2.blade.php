@extends('layouts.app2')

@section("content")
  <div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
        	 <h1>ABOUT PHP2 SUBJECT</h1>
           <div class="panel panel-default">
              <div class="panel-body" style="font-size:26px">
              	&nbsp &nbsp &nbsp&nbsp &nbsp &nbsp &nbsp &nbspPHP2 is general-purpose scripting language that is especially suited to server-side web development, in which case PHP generally runs on a web server.<BR><BR> 
                &nbsp &nbsp &nbsp&nbsp &nbsp &nbsp &nbsp &nbspUsually to create dynamic web page content or dynamic images used on websites or elsewhere.<BR><BR> 
                &nbsp &nbsp &nbsp&nbsp &nbsp &nbsp &nbsp &nbspDuring my PHP2 class we tackled about UI design, front-end and back-end design, MVC, Session and frameworks.
              </div>
            </div>
            </div>
        </div>
    </div>
</div>
@stop